/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-inferrable-types */


import { Injectable } from '@angular/core';
import * as XLSX from 'xlsx-js-style';

@Injectable({
  providedIn: 'root'
})
export class IbexcelreportService {


  exportAuditReport(jsonData: any, fileName: string = 'ACCOUNTS_AUDIT_REPORT.xlsx') {
    
    // 1. Define Reusable Styles
    const styles = {
      mainTitle: {
        font: { bold: true, sz: 14, color: { rgb: "000000" } },
        alignment: { horizontal: "center", vertical: "center" }
      },
      headerLabel: {
        font: { bold: true, sz: 11 }
      },
      sectionTitle: {
        font: { bold: true, sz: 11 },
        fill: { fgColor: { rgb: "D9D9D9" } }, // Light Gray
        alignment: { horizontal: "left", vertical: "center" }
      },
      tableHeader: {
        font: { bold: true, sz: 11 },
        fill: { fgColor: { rgb: "F2F2F2" } },
        alignment: { horizontal: "center", vertical: "center", wrapText: true },
        border: {
          top: { style: "thin", color: { rgb: "000000" } },
          bottom: { style: "thin", color: { rgb: "000000" } },
          left: { style: "thin", color: { rgb: "000000" } },
          right: { style: "thin", color: { rgb: "000000" } }
        }
      },
      tableBody: {
        alignment: { vertical: "center", wrapText: true },
        border: {
          top: { style: "thin", color: { rgb: "000000" } },
          bottom: { style: "thin", color: { rgb: "000000" } },
          left: { style: "thin", color: { rgb: "000000" } },
          right: { style: "thin", color: { rgb: "000000" } }
        }
      }
    };

    // 2. Build the Layout (Array of Arrays)
    const aoa: any[][] = [
      [], // 0: Margin
      [], // 1: Margin
      ['ACCOUNTS AUDIT REPORT DATED'], // 2: Main Title (Will be merged)
      [], // 3: Spacer
      ['Branch Name and Code', '', `${jsonData.branch || ''}`, '', 'Opening date', '', jsonData.openingDate || ''], // 4
      ['State', '', jsonData.state || '', '', 'Previous audit date', '', jsonData.previousAuditDate || ''], // 5
      ['Period covered', '', jsonData.periodCoveredFrom || '', 'To', jsonData.closingDate || ''], // 6
      [], // 7: Spacer
      
      // Section I
      ['I) Branch staff details (Staff strength including MF, Auto Loan etc)'], // 8
      ['Sl.No', 'Name', 'Emp code', 'Designation', 'Date of Joining', 'Contact Number', 'ID card & other assets available', 'Remarks'] // 9
    ];

    // Track the row index where dynamic staff data starts
    const staffStartRow = aoa.length; 
    let staffCount = 0;

    // 3. Populate Dynamic Data
    if (jsonData.staffDetails && Array.isArray(jsonData.staffDetails)) {
      jsonData.staffDetails.forEach((staff: any, index: number) => {
        aoa.push([
          index + 1,
          staff.employeeName || '',
          staff.employeeCode || '',
          staff.designation || '',
          staff.dateOfJoining || '',
          staff.contactNumber || '',
          staff.idCardOrAssetsAvailable || '',
          staff.remarks || ''
        ]);
        staffCount++;
      });
    }

    // 4. Convert AOA to Worksheet
    const ws: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(aoa);

    // 5. Apply Column Widths
    ws['!cols'] = [
      { wch: 6 },   // A: Sl.No / Labels
      { wch: 25 },  // B: Name
      { wch: 15 },  // C: Emp code
      { wch: 20 },  // D: Designation
      { wch: 15 },  // E: Date of Joining
      { wch: 15 },  // F: Contact
      { wch: 20 },  // G: ID Card
      { wch: 30 }   // H: Remarks
    ];

    // 6. Apply Merges
    ws['!merges'] = [
      { s: { r: 2, c: 0 }, e: { r: 2, c: 7 } }, // Merge Main Title across A to H
      { s: { r: 8, c: 0 }, e: { r: 8, c: 7 } }, // Merge Section I Title across A to H
      // Merge Header labels across 2 columns for better spacing
      { s: { r: 4, c: 0 }, e: { r: 4, c: 1 } }, 
      { s: { r: 5, c: 0 }, e: { r: 5, c: 1 } },
      { s: { r: 6, c: 0 }, e: { r: 6, c: 1 } },
    ];

    // 7. Styling Engine (Crucial for xlsx-js-style)
    const applyStyle = (row: number, col: number, style: any) => {
      const cellRef = XLSX.utils.encode_cell({ c: col, r: row });
      // If cell doesn't exist (empty cell in a merge or blank space), create it
      if (!ws[cellRef]) {
        ws[cellRef] = { t: 's', v: '' }; 
      }
      // Attach the style object
      ws[cellRef].s = style;
    };

    // Apply Main Title Style
    for (let c = 0; c <= 7; c++) applyStyle(2, c, styles.mainTitle);

    // Apply Header Labels Style (Rows 4, 5, 6)
    [4, 5, 6].forEach(r => {
      applyStyle(r, 0, styles.headerLabel); // Labels
      applyStyle(r, 4, styles.headerLabel); // Secondary Labels
    });

    // Apply Section Title Style (Row 8)
    for (let c = 0; c <= 7; c++) applyStyle(8, c, styles.sectionTitle);

    // Apply Table Header Style (Row 9)
    for (let c = 0; c <= 7; c++) applyStyle(9, c, styles.tableHeader);

    // Apply Table Body Style (Dynamic Rows)
    for (let r = staffStartRow; r < staffStartRow + staffCount; r++) {
      for (let c = 0; c <= 7; c++) {
        applyStyle(r, c, styles.tableBody);
      }
    }

    // 8. Generate and Download
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Audit Report');
    XLSX.writeFile(wb, fileName);
  }
}